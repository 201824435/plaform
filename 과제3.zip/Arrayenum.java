import java.util.Scanner;
import java.lang.Math;

import static java.lang.Math.sqrt;

enum Command {
    ADD, LIST, SUM, AVG, STD, QUIT,INVALID
    };

public class Arrayenum {
    public static void main(String[] args) {

        int values[] = new int[100];
        int index = 0;

        final Scanner scanner = new Scanner(System.in);
        while (true) {
            System.out.println("명령어를 입력하세요. ADD, LIST, SUM, AVG, STD, QUIT.");
            Command command = getCommand(scanner);
            if (command == Command.QUIT) {
                System.out.println("Bye!");
                break;
            }
            switch (command) {
                case ADD:
                    int newValue = getValue(scanner);
                    values[index] = newValue;
                    index++;
                    break;
                case SUM:
                    int sum = getSum(values, index);
                    System.out.println(sum);
                    break;
                case LIST:
                    printList(values, index);
                    break;
                case AVG:
                    System.out.printf("%.2f\n", getAvg(values, index));
                    break;
                case STD:
                    System.out.printf("%.2f\n", getStd(values, index));
                    break;
                case INVALID:
                    System.out.println("Invalid Command");
                    break;
                default:
                    break;
            }
        }
        scanner.close();
    }


    private static Command getCommand(Scanner scan) {
        String strCom = scan.next();

        Command kind;
        try {
            kind = Command.valueOf(strCom.toUpperCase());
        } catch (IllegalArgumentException e) {
            kind = Command.INVALID;
        }
        return kind;
    }

    private static int getValue(Scanner scan) {
        int gValue = scan.nextInt();
        scan.nextLine();
        return gValue;
    }

    private static int getSum(int values[], int i) {
        int sum = 0;
        for (int n = 0; n < i; n++) {
            sum = sum + values[n];
        }
        return sum;
    }

    private static void printList(int values[], int i) {
        for (int n = 0; n < i; n++) {
            System.out.print(values[n]);
            System.out.print(" ");
        }
        System.out.println();
    }

    private static double getAvg(int values[], int i) {
        int sum = 0;
        double avg = 0;
        for (int n = 0; n < i; n++) {
            sum = sum + values[n];
        }
        avg = (double) sum / (double) (i);

        return avg;
    }

    private static double getStd(int values[], int i) {
        int sum = 0;
        double avg = 0;
        double std = 0;
        for (int n = 0; n < i; n++) {
            sum = sum + values[n];
        }
        avg = (double) sum / (double) (i);
        sum = 0;
        for (int n = 0; n < i; n++) {
            sum += Math.pow((values[n] - avg), 2);
        }
        std = Math.sqrt(sum / i);
        return std;
    }
}
