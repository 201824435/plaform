import java.util.Scanner;

public class MathMain {
    public static void main(String[] args){
        Scanner scan = new Scanner(System.in);
        System.out.print("Enter a begin number: ");
        int begin = scan.nextInt();
        System.out.print("Enter an end number: ");
        int end = scan.nextInt();

        long sum = getSumBetween(begin, end);
        System.out.printf("Sum between %d and %d : %,d%n", begin , end, sum);

        long sumProduct = getProductBetween(begin, end);
        System.out.printf("Product between %d and %d : %,d%n", begin , end, sumProduct);

        scan.close();
    }

    static long getSumBetween( int begin, int end ) {
        int getSum = 0;
        for ( int i = begin; i < end+1 ; i++) {
            getSum = getSum + i;
        }
        return (long)getSum;
    }

    static long getProductBetween( int begin, int end ) {
        int getSum = 1;
        for ( int i = begin; i < end+1 ; i++) {
            getSum = getSum * i;
        }
        return (long)getSum;
    }
}
