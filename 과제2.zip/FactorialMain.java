import java.util.Scanner;

public class FactorialMain {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        System.out.print("Enter a number: ");
        int number = scan.nextInt();
        for (int i = 1; i <= number; i++) {
            System.out.print("Factorial of ");
            System.out.print(i);
            System.out.print(" = ");
            System.out.println( getFactorial( i ) );
        }
    }
    private static long getFactorial ( final int n){
        int sum = 1;
        for (int i = 1; i <= n; i++) {
            sum = sum * i;
            }
        return (long)sum;
        }

}