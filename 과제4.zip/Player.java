import java.util.Objects;

public class Player {
    private String firstName;
    private String lastName;
    private int jerseyNumber;

    public Player() {};
    public Player( String playerFirstName, int jerseyNumber) {
        firstName = playerFirstName;
        this.jerseyNumber = jerseyNumber;
    }
    public Player( String playerFirstName, String playerLastName, int jerseyNumber) {
        firstName = playerFirstName;
        lastName = playerLastName;
        this.jerseyNumber = jerseyNumber;
    }
    public String toString() {
        String msg = "[" + lastName + ", " + firstName + " " + jerseyNumber + "]";
        return msg;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Player player = (Player) o;
        return jerseyNumber == player.jerseyNumber && firstName.equals(player.firstName);
    }

    @Override
    public int hashCode() {
        return Objects.hash(firstName, lastName, jerseyNumber);
    }
}
