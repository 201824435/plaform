package edu.pnu.collection;

public class GenericList<T> {
    private static final int DEFAULT_SIZE = 10;
    private Object[] data;
    private int size = 0;

    public GenericList() {
        data = new Object[size];
        for (int i = 0; i < size; i++) {
            data[i] = new Object();
        }
    }

    public int setSize() {
        return size;
    }

    public Object add(T player) {
        for (int i = 0; i < size; i++) {
            if (data[i] == null) {
                data[i] = player;
                return data;
            }
        }
        size++;
        Object[] temp = new Object[size];
        for(int i = 0; i < size-1; i++) {
            temp[i] = data[i];
        }
        temp[size-1] = player;
        data = temp;
        return data;
    }

    public void remove() {
        for (int i = 0; i < size; i++) {
            data[i] = null;
        }
        size = 0;
    }

    public Object get(int index) {
        return data[index];
    }
}