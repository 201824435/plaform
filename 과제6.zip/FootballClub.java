package edu.pnu.admin;

import edu.pnu.collection.*;
import java.util.Objects;

public class FootballClub {
    private String name;
    private final int maxSquadSize = 25;
    private GenericList<Player> squad = new GenericList<Player>();

    public FootballClub(String name) {
        this.name = name;
    }

    public void addPlayer(Player p) {
        squad.add(p);
    }

    public void removeAllPlayer() {
        squad.remove();
    }

    public Player findPlayer(String playerFirstName, int jerseyNumber) {
        Player p = new Player(playerFirstName,jerseyNumber);
        for(int i =0; i < squad.setSize(); i++) {
            if(p.equals(squad.get(i)) ) {
                return (Player) squad.get(i);
            }
        }
        return null;
    }

    @Override
    public String toString() {
        String msg = "FootballClub Name: " + name + "Player Counter" + squad.setSize() + "\n";
        for(int i = 0; i < squad.setSize(); i++) {
            msg += "\t" + squad.get(i) + "\n";
        }
        return msg;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass() ) return false;
        FootballClub that = (FootballClub) o;
        return maxSquadSize == that.maxSquadSize && name.equals(that.name) && squad.equals(that.squad);
    }

    @Override
    public int hashCode() {
        return Objects.hash(name, maxSquadSize, squad);
    }
}